package org.yohang.chunky;

import com.google.inject.Inject;
import net.kyori.adventure.identity.Identity;
import net.kyori.adventure.text.Component;
import net.kyori.adventure.text.LinearComponents;
import net.kyori.adventure.text.format.NamedTextColor;
import net.kyori.adventure.text.format.Style;
import net.kyori.adventure.text.format.TextDecoration;
import org.apache.logging.log4j.Logger;
import org.spongepowered.api.Server;
import org.spongepowered.api.block.BlockType;
import org.spongepowered.api.block.BlockTypes;
import org.spongepowered.api.command.Command;
import org.spongepowered.api.command.CommandResult;
import org.spongepowered.api.command.parameter.Parameter;
import org.spongepowered.api.event.Listener;
import org.spongepowered.api.event.block.ChangeBlockEvent;
import org.spongepowered.api.event.block.InteractBlockEvent;
import org.spongepowered.api.event.lifecycle.ConstructPluginEvent;
import org.spongepowered.api.event.lifecycle.RegisterCommandEvent;
import org.spongepowered.api.event.lifecycle.StartingEngineEvent;
import org.spongepowered.api.event.lifecycle.StoppingEngineEvent;
import org.spongepowered.plugin.PluginContainer;
import org.spongepowered.plugin.builtin.jvm.Plugin;

import java.io.DataOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;

/**
 * The main class of your Sponge plugin.
 *
 * <p>All methods are optional -- some common event registrations are included as a jumping-off point.</p>
 */
@Plugin("chunky")
public class Chunky {

    private final PluginContainer container;
    private final Logger logger;

    @Inject
    Chunky(final PluginContainer container, final Logger logger) {
        this.container = container;
        this.logger = logger;
    }

    @Listener
    public void onConstructPlugin(final ConstructPluginEvent event) {
        // Perform any one-time setup
        this.logger.info("Constructing chunky");
    }

    private static int mapBlockType(BlockType type) {
//        Air = 0,
//        Stone = 1,
//        Grass = 2,
//        Dirt = 3,
//        Water = 4,
//        Sand = 5,
//        Gravel = 6,
//        Log = 7,
//        Leaves = 8,
//        Planks = 9,
        if (type.equals(BlockTypes.AIR.get())) {
            return 0;
        }
        if (type.equals(BlockTypes.TALL_GRASS.get())) {
            return 0;
        }
        if (type.equals(BlockTypes.GRASS.get())) {
            return 0;
        }
        if (type.equals(BlockTypes.OXEYE_DAISY.get())) {
            return 0;
        }
        if (type.equals(BlockTypes.DANDELION.get())) {
            return 0;
        }
        if (type.equals(BlockTypes.CORNFLOWER.get())) {
            return 0;
        }
        if (type.equals(BlockTypes.STONE.get())) {
            return 1;
        }
        if (type.equals(BlockTypes.GRASS_BLOCK.get())) {
            return 2;
        }
        if (type.equals(BlockTypes.DIRT.get())) {
            return 3;
        }
        if (type.equals(BlockTypes.WATER.get())) {
            return 4;
        }
        if (type.equals(BlockTypes.SAND.get())) {
            return 5;
        }
        if (type.equals(BlockTypes.GRAVEL.get())) {
            return 6;
        }
        if (type.equals(BlockTypes.SPRUCE_LOG.get())) {
            return 7;
        }
        if (type.equals(BlockTypes.DARK_OAK_LOG.get())) {
            return 7;
        }
        if (type.equals(BlockTypes.OAK_LOG.get())) {
            return 7;
        }
        if (type.equals(BlockTypes.OAK_LEAVES.get())) {
            return 8;
        }
        if (type.equals(BlockTypes.SPRUCE_LEAVES.get())) {
            return 8;
        }
        if (type.equals(BlockTypes.DARK_OAK_LEAVES.get())) {
            return 8;
        }
        if (type.equals(BlockTypes.OAK_PLANKS.get())) {
            return 9;
        }
        if (type.equals(BlockTypes.SPRUCE_PLANKS.get())) {
            return 9;
        }
        if (type.equals(BlockTypes.DARK_OAK_PLANKS.get())) {
            return 9;
        }
        return 255;
    }

    @Listener
    public void onInteractBlock(InteractBlockEvent event) throws IOException {
        final int SIZE = 16;

        var block = event.block().position();
        var world = event.block().location().get().world();
        var chunk = world.chunkAtBlock(block);
        var pos = world.closestPlayer(block, 64).get().position();

        var file = new FileOutputStream("chunk.bin");
        var data = new DataOutputStream(file);

        for (var w = SIZE - 1; w >= 0; w--) {
            var y = w + pos.floorY() - SIZE / 2;
            for (var z = 0; z < SIZE; z++) {
                for (var x = 0; x < SIZE; x++) {
                    var type = chunk.block(x, y, z).type();

                    data.writeByte(mapBlockType(type));
                }
            }
        }
        file.close();
        data.close();
        System.out.println("chunk: " + chunk.chunkPosition() + " saved at " + file);
    }

    @Listener
    public void onServerStarting(final StartingEngineEvent<Server> event) {
        // Any setup per-game instance. This can run multiple times when
        // using the integrated (singleplayer) server.
    }

    @Listener
    public void onServerStopping(final StoppingEngineEvent<Server> event) {
        // Any tear down per-game instance. This can run multiple times when
        // using the integrated (singleplayer) server.
    }

    @Listener
    public void onRegisterCommands(final RegisterCommandEvent<Command.Parameterized> event) {
        // Register a simple command
        // When possible, all commands should be registered within a command register event
        final Parameter.Value<String> nameParam = Parameter.string().key("name").build();
        event.register(this.container, Command.builder()
            .addParameter(nameParam)
            .permission("chunky.command.greet")
            .executor(ctx -> {
                final String name = ctx.requireOne(nameParam);
                ctx.sendMessage(Identity.nil(), LinearComponents.linear(
                    NamedTextColor.AQUA,
                    Component.text("Hello "),
                    Component.text(name, Style.style(TextDecoration.BOLD)),
                    Component.text("!")
                ));

                return CommandResult.success();
            })
            .build(), "greet", "wave");
    }
}
