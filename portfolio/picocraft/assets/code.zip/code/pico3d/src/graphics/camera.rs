use crate::{
    game::{WIDTH, HEIGHT},
    voxel::{World, Ray, Block},
    screen::Rgb565,
    math::{Fixed, Vec3, Vec2}
};

pub struct Camera {
    pub pos: Vec3<Fixed>,
    pub lookat: Vec3<Fixed>,
    // pub dir: Vec3<Fixed>,
    // TODO: (maybe) camera roll
}

impl Camera {
    pub const FOCAL_LENGTH: f32 = 1.0;
    pub const VIEWPORT_HEIGHT: f32 = 2.0;
    pub const VIEWPORT_WIDTH: f32 = Self::VIEWPORT_HEIGHT * (WIDTH as f32) / (HEIGHT as f32);
    pub const SUN_DIR: Vec3<i32> = Vec3::new(1, -5, 2);

    pub fn render(&self, world: &World, sbuf: &mut [Rgb565], offset: usize) {
        // Calculate orthonormal basis of camera
        let mut w = self.pos - self.lookat;
        w /= w.magnitude_squared().sqrt();
        let mut u = Vec3::new(Fixed::zero(), Fixed::one(), Fixed::zero()).cross(w);
        u /= u.magnitude_squared().sqrt();
        let v = w.cross(u);
        
        // UV vectors that span the viewport in world coordinates
        let viewport = Vec2::new(
            u * Fixed::new(Self::VIEWPORT_WIDTH),
            -v * Fixed::new(Self::VIEWPORT_HEIGHT),
        );
        // Delta vectors from pixel to pixel
        let pixel_delta = Vec2::new(
            viewport.x / Fixed::from(WIDTH as i32),
            viewport.y / Fixed::from(HEIGHT as i32),
        );
        // Upper left pixel
        let viewport_corner = self.pos - (w * Fixed::new(Self::FOCAL_LENGTH)) - (viewport.sum() / Fixed::from(2i32));
        let pixel_center = viewport_corner + (pixel_delta.sum() / Fixed::from(2));

        let mut ray = Ray::default();
        ray.origin = self.pos;
        for (i, px) in sbuf.iter_mut().enumerate() {
            let x: Fixed = (((i + offset) % WIDTH) as i32).into();
            let y: Fixed = (((i + offset) / WIDTH) as i32).into();
            
            let pixel = pixel_center + (pixel_delta.x * x) + (pixel_delta.y * y);
            ray.dir = pixel - self.pos;

            if let Ok(_) = ray.cast(world) {
                let light = Fixed::from(ray.hit_norm().dot(Self::SUN_DIR)).min(Fixed::new(0.1));
                let ambient = Fixed::<15>::new(0.5);
                let albedo = ray.hit().color();
                // let randomness = Fixed::<15>::new(0.1) * (ray.hit_pos().x % 5 + (ray.hit_pos().z / 2) % 5).into();

                *px = albedo.scale(Fixed::<15>::new(0.3) * light + ambient).flip();
            } else {
                *px = Rgb565::new(174, 200, 235).flip();
            }
        }
    }
}