use crate::screen::Rgb565;

#[derive(Debug, Clone, Copy, Default, PartialEq, Eq)]
#[repr(u8)]
pub enum Block {
    #[default]
    Air = 0,
    Stone = 1,
    Grass = 2,
    Dirt = 3,
    Water = 4,
    Sand = 5,
    Gravel = 6,
    Log = 7,
    Leaves = 8,
    Planks = 9,

    Unknown = 255,
}

impl Block {
    pub const EMPTY: Self = Self::Air;

    pub fn color(&self) -> Rgb565 {
        static MAP: &[Rgb565] = &[
            Rgb565::BLACK,              // Air
            Rgb565::new(120, 121, 125), // Stone
            Rgb565::new(77, 168, 71),   // Grass
            Rgb565::new(130, 74, 46),   // Dirt
            Rgb565::new(43, 111, 189),  // Water
            Rgb565::new(227, 186, 116), // Sand
            Rgb565::new(126, 131, 135), // Gravel
            Rgb565::new(54, 31, 12),    // Log
            Rgb565::new(64, 79, 57),    // Leaves
            Rgb565::new(119, 144, 82),  // Planks
        ];
        match self {
            Block::Unknown => Rgb565::new(245, 66, 227),
            _ => MAP[*self as usize]
        }
    }
}