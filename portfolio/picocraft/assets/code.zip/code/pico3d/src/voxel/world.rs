use cortex_m::singleton;
use vek::Vec3;

use super::Block;

pub struct World {
    pub blocks: &'static mut [Block; Self::VOLUME]
}

impl World {
    /// Size of the world along 1 dimension
    pub const SIZE: usize = 16;
    pub const VOLUME: usize = Self::SIZE.pow(3);

    const fn map_index(i: Vec3<i32>) -> usize {
        (i.y as usize * Self::SIZE.pow(2))
        + (i.z as usize * Self::SIZE)
        + (i.x as usize)
    }

    pub fn get(&self, i: Vec3<i32>) -> Option<&Block> {
        if i.iter().any(|&x| x < 0 || x >= Self::SIZE as _) {
            None
        } else {
            Some(unsafe {
                self.blocks.get_unchecked(Self::map_index(i))
            })
        }
    }

    pub fn get_mut(&mut self, i: Vec3<i32>) -> Option<&mut Block> {
        if i.iter().any(|&x| x < 0 || x >= Self::SIZE as _) {
            None
        } else {
            Some(unsafe {
                self.blocks.get_unchecked_mut(Self::map_index(i))
            })
        }
    }
}

impl core::ops::Index<Vec3<i32>> for World {
    type Output = Block;

    fn index(&self, index: Vec3<i32>) -> &Self::Output {
        self.get(index).unwrap()
    }
}

impl core::ops::IndexMut<Vec3<i32>> for World {
    fn index_mut(&mut self, index: Vec3<i32>) -> &mut Self::Output {
        self.get_mut(index).unwrap()
    }
}

impl World {
    pub fn new_demo() -> Self {
        let blocks = singleton!(: [Block; World::VOLUME] = [Block::EMPTY; World::VOLUME]).unwrap();
        let mut world = Self { blocks };

        // world[Vec3::new(8, 9, 8)] = Block::Stone;
        // world[Vec3::new(8, 8, 8)] = Block::Grass;
        // world[Vec3::new(8, 7, 8)] = Block::Stone;
        // world[Vec3::new(8, 6, 8)] = Block::Grass;
        // world[Vec3::new(8, 5, 8)] = Block::Stone;

        // world[Vec3::new(8, 6, 7)] = Block::Stone;
        let test_chunk = include_bytes!("../../assets/chunk.bin");

        world.blocks.copy_from_slice(unsafe { core::slice::from_raw_parts(test_chunk.as_ptr() as _, test_chunk.len()) });

        world
    }
}