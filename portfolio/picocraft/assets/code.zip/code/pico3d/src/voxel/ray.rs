use crate::math::{Fixed, Vec3};
use super::{World, Block};

#[derive(Debug, Default, Clone)]
pub struct Ray {
    // Input
    pub origin: Vec3<Fixed>,
    pub dir: Vec3<Fixed>,

    // Outputs
    hit: Block,
    hit_pos: Vec3<i32>,
    hit_norm: Vec3<i32>,
}

impl Ray {
    pub fn cast(&mut self, world: &World) -> Result<(), ()> {
        enum Axis { None, X, Y, Z }

        // Normalized direction vector
        // let dir = self.dir.try_normalized().ok_or(())?;
        let mag = self.dir.magnitude_squared().sqrt();
        
        if mag == Fixed::zero() {
            return Err(());
        }
        let dir = self.dir / mag;

        // Initial voxel position (= floor(i))
        // TODO: start inside the grid? maybe this doesn't matter since player is inside loaded chunk
        let mut i = self.origin.map(|x| x.int() as i32);
        
        // Unitary step along each axis
        let step = dir.map(|x| if x > Fixed::zero() { 1 } else { -1 } );
        
        // Movement along each axis per unit t 
        let dt = dir.map(|x| Fixed::one().try_div(x).unwrap_or(Fixed::max()).abs());
        let dist = step.map3(i, self.origin, |step, i, p| if step > 0 { Fixed::from(i) + Fixed::one() - p } else { p - Fixed::from(i) });
        
        // Nearest voxel boundary in units of t
        let mut tmax = dt.map3(dist, dir, |dt, dist, dir| if dir != Fixed::zero() { dt * dist } else { Fixed::max() });

        // Axis along which we last moved
        let mut last_step = Axis::None;
        let mut num_steps = 0;

        loop {
            // Fail condition -> Exited Grid
            // TODO: explicit get without loading
            let hit = world.get(i).or_else(|| {
                // TODO: better projection
                if num_steps < 8 {
                    Some(&Block::EMPTY)
                } else {
                    None
                }
            }).ok_or(())?;
            // Exit condition -> Found a block!
            if *hit != Block::EMPTY {
                self.hit = *hit;
                self.hit_pos = i;
                self.hit_norm = match last_step {
                    Axis::None => Vec3::zero(),
                    Axis::X => Vec3::new(-step[0], 0, 0),
                    Axis::Y => Vec3::new(0, -step[1], 0),
                    Axis::Z => Vec3::new(0, 0, -step[2]),
                };
                break Ok(())
            }

            // Advance to the next voxel
            if tmax.x < tmax.y {
                if tmax.x < tmax.z {
                    i.x += step.x;
                    tmax.x += dt.x;
                    last_step = Axis::X;
                } else {
                    i.z += step.z;
                    tmax.z += dt.z;
                    last_step = Axis::Z;
                }
            } else {
                if tmax.y < tmax.z {
                    i.y += step.y;
                    tmax.y += dt.y;
                    last_step = Axis::Y;
                } else {
                    i.z += step.z;
                    tmax.z += dt.z;
                    last_step = Axis::Z;
                }
            }
            num_steps += 1;
        }
    }

    pub fn hit(&self) -> Block {
        self.hit
    }

    pub fn hit_norm(&self) -> Vec3<i32> {
        self.hit_norm
    }

    pub fn hit_pos(&self) -> Vec3<i32> {
        self.hit_pos
    }
}