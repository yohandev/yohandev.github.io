use cortex_m::singleton;
use embedded_hal::digital::v2::ToggleableOutputPin;
use rp_pico::hal::uart::UartPeripheral;
use vek::num_traits::Float;
use defmt::*;

use crate::{
    screen::{Screen, Rgb565},
    graphics::Camera,
    voxel::World,
    math::{Vec3, Fixed},
};

pub const WIDTH: usize = 160;
pub const HEIGHT: usize = 128;

pub fn core0(
    screen: &mut impl Screen,
    led: &mut impl ToggleableOutputPin,
    serial_available: impl Fn() -> bool,
    mut serial_read: impl FnMut(&'static mut [u8]) -> bool,
) -> ! {
    info!("Start!");

    let sbuf0 = singleton!(: [Rgb565; WIDTH * HEIGHT] = [Rgb565::BLACK; WIDTH * HEIGHT]).unwrap();
    let sbuf1 = singleton!(: [Rgb565; WIDTH * HEIGHT] = [Rgb565(0b111111); WIDTH * HEIGHT]).unwrap();

    // Put sbuf#1 into transfer and swap sbuf#0 later, ad infinitum
    let mut sbuf: &mut [Rgb565] = sbuf0;
    screen.write(sbuf1).unwrap();

    let mut sio = sio();

    let world = World::new_demo();
    let mut cam = Camera {
        // Look at the center of the chunk
        lookat: Vec3::new(8.into(), 8.into(), 8.into()),
        pos: Vec3::new(Fixed::new(5.0), Fixed::new(10.0), Fixed::new(15.0)),
    };
    let mut t = 0.0f32;

    loop {
        // Update
        cam.pos = cam.lookat + (Vec3::new(Fixed::new(t.cos()), Fixed::new(-0.5), Fixed::new(t.sin())) * Fixed::from(9i32));
        t += 0.1;

        // info!("{}, {}, {}", cam.pos.x.int(), cam.pos.y.int(), cam.pos.z.int());

        {
            // Split our render into two halves
            let (sbuf0, sbuf1) = sbuf.split_at_mut(WIDTH * HEIGHT / 2);

            // Render second half of screen buffer
            sio.fifo.write_blocking(&world as *const _ as u32);
            sio.fifo.write_blocking(sbuf1.as_mut_ptr() as u32);
            sio.fifo.write_blocking(&cam as *const _ as u32);

            // Render first half of screen buffer
            cam.render(&world, sbuf0, 0);

            // Synchronize render
            let _sync = sio.fifo.read_blocking();
        }
        // info!("{}", sbuf.len());

        // Display
        sbuf = screen.swap(sbuf).unwrap();

        if serial_read(unsafe { core::slice::from_raw_parts_mut(world.blocks as *mut _ as *mut u8, world.blocks.len()) }) {
            led.toggle().ok().unwrap();
        }

        // for _ in 0..500_000 {
        //     cortex_m::asm::nop();
        // }
    }
}

pub fn core1() -> ! {
    let mut sio = sio();

    loop {
        let world_addr = sio.fifo.read_blocking() as *const World;
        let sbuf_addr = sio.fifo.read_blocking() as *mut Rgb565;
        let cam_addr = sio.fifo.read_blocking() as *const Camera;

        let world = unsafe { &*world_addr };
        let sbuf = unsafe { core::slice::from_raw_parts_mut(sbuf_addr, WIDTH * HEIGHT / 2) };
        let cam = unsafe { &*cam_addr };

        cam.render(world, sbuf, WIDTH * HEIGHT / 2);

        // Synchronize
        sio.fifo.write_blocking(1);
    }
}

fn sio() -> rp_pico::hal::Sio {
    rp_pico::hal::Sio::new(unsafe { rp_pico::pac::Peripherals::steal() }.SIO)
}