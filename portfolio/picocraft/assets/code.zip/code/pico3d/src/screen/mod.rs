pub use rgb565::Rgb565;
pub use st7735::St7735;

mod rgb565;
mod st7735;

pub trait Screen {
    fn write(&mut self, sbuf: &'static mut [Rgb565]) -> Result<(), ()>;
    fn is_done(&self) -> bool;
    fn wait(&mut self) -> Result<&'static mut [Rgb565], ()>;

    fn swap(&mut self, sbuf: &'static mut [Rgb565]) -> Result<&'static mut [Rgb565], ()> {
        let old = self.wait()?;
        self.write(sbuf)?;
        
        Ok(old)
    }
}