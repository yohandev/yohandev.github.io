use rp_pico::hal::dma::{
    self,
    SingleChannel,
    single_buffer::{Config, Transfer},
};
use embedded_hal::blocking::{
    spi,
    delay::DelayMs,
};
use embedded_hal::digital::v2::OutputPin;

use crate::screen::{Screen, Rgb565};

pub struct St7735<Spi, Dma, Dc, Rst>
where
    Spi: spi::Write<u8> + dma::WriteTarget<TransmittedWord = u8>,
    Dma: SingleChannel,
    Dc: OutputPin,
    Rst: OutputPin,
{
    tx: Option<(Spi, Dma)>,
    transfer: Option<Transfer<Dma, &'static mut [u8], Spi>>,

    dc: Dc,
    rst: Rst,
}

#[allow(unused)]
enum Instruction {
    NOP         = 0x00,
    SWRESET     = 0x01,
    SLPIN       = 0x10,  // sleep on
    SLPOUT      = 0x11,  // sleep off
    PTLON       = 0x12,  // partial on
    NORON       = 0x13,  // partial off
    INVOFF      = 0x20,  // invert off
    INVON       = 0x21,  // invert on
    DISPOFF     = 0x28,  // display off
    DISPON      = 0x29,  // display on
    IDMOFF      = 0x38,  // idle off
    IDMON       = 0x39,  // idle on
    CASET       = 0x2A,
    RASET       = 0x2B,
    RAMWR       = 0x2C,
    RAMRD       = 0x2E,
    COLMOD      = 0x3A,
    MADCTL      = 0x36,
    PTLAR       = 0x30,   // partial start/end
    VSCRDEF     = 0x33,   // SETSCROLLAREA
    VSCRSADD    = 0x37,
    WRDISBV     = 0x51,
    WRCTRLD     = 0x53,
    WRCACE      = 0x55,
    WRCABCMB    = 0x5e,
    POWSAVE     = 0xbc,
    DLPOFFSAVE  = 0xbd,
    FRMCTR1     = 0xB1,
    FRMCTR2     = 0xB2,
    FRMCTR3     = 0xB3,
    INVCTR      = 0xB4,
    DISSET5     = 0xB6,
    PWCTR1      = 0xC0,
    PWCTR2      = 0xC1,
    PWCTR3      = 0xC2,
    PWCTR4      = 0xC3,
    PWCTR5      = 0xC4,
    VMCTR1      = 0xC5,
    PWCTR6      = 0xFC,
    GMCTRP1     = 0xE0,
    GMCTRN1     = 0xE1,
}

impl<Spi, Dma, Dc, Rst> St7735<Spi, Dma, Dc, Rst>
where
    Spi: spi::Write<u8> + dma::WriteTarget<TransmittedWord = u8>,
    Dma: SingleChannel,
    Dc: OutputPin,
    Rst: OutputPin,
{
    pub fn new(spi: Spi, dma: Dma, dc: Dc, rst: Rst) -> Self {
        Self {
            tx: Some((spi, dma)),
            transfer: None,
            dc,
            rst
        }
    }

    pub fn init(&mut self, width: u8, height: u8, delay: &mut impl DelayMs<u8>) -> Result<(), ()> {
        self.hard_reset(delay)?;
        self.write_command(Instruction::SWRESET, &[])?; // Software Reset
        delay.delay_ms(250);
        self.write_command(Instruction::SLPOUT, &[])?;  // Out of Sleep Mode
        delay.delay_ms(250);

        self.write_command(Instruction::FRMCTR1, &[0x01, 0x2C, 0x2D])?; // Framerate Control, Normal
                                                                        // Rate = fosc/(1x2+40) * (LINE+2C+2D)
        self.write_command(Instruction::FRMCTR2, &[0x01, 0x2C, 0x2D])?; // Framerate Control, Idle
                                                                        // Rate = fosc/(1x2+40) * (LINE+2C+2D)
        self.write_command(Instruction::FRMCTR3, &[                     // Framerate Control, Partial
            0x01, 0x2C, 0x2D,   // Dot Inversion Mode
            0x01, 0x2C, 0x2D    // Line Inversion Mode
        ])?;

        self.write_command(Instruction::INVCTR, &[0x07])?;              // Display Inversion: None

        self.write_command(Instruction::PWCTR1, &[0xA2, 0x02, 0x84])?;  // Power Control: -4.6V, AUTO Mode
        self.write_command(Instruction::PWCTR2, &[0xC5])?;              // Power Control: VGH25=2.4C VGSEL=-10 VGH=3 * AVDD
        self.write_command(Instruction::PWCTR3, &[0x0A, 0x00])?;        // Power Control: Op-Amp Currnet Small, Boost Frequency
        self.write_command(Instruction::PWCTR4, &[0x8A, 0x2A])?;        // Power Control: BCLK/2, Op-Amp Current Small & Medium Low
        self.write_command(Instruction::PWCTR5, &[0x8A, 0xEE])?;        // Power Control
        self.write_command(Instruction::VMCTR1, &[0x0E])?;              // Power Control

        self.write_command(Instruction::INVOFF, &[])?;                  // Display Inversion: Off
        self.write_command(Instruction::MADCTL, &[0x20])?;              // Memory Access Control: Row/Col Addr, bottom-top refresh
        self.write_command(Instruction::COLMOD, &[0x05])?;              // Color Mode
        self.write_command(Instruction::CASET, &[                       // Column Address Set
            0x0, 0x0,
            0x0, width - 1,
        ])?;
        self.write_command(Instruction::RASET, &[                       // Row Address Set
            0x0, 0x0,
            0x0, height - 1,
        ])?;

        // self.write_command(Instruction::GMCTRP1, &[                     // Gamma Adjustments (pos. polarity)
        //     0x02, 0x1c, 0x07, 0x12,
        //     0x37, 0x32, 0x29, 0x2d,
        //     0x29, 0x25, 0x2B, 0x39,
        //     0x00, 0x01, 0x03, 0x10,
        // ])?;
        // self.write_command(Instruction::GMCTRN1, &[                     // Gamma Adjustments (neg. polarity)
        //     0x03, 0x1d, 0x07, 0x06,
        //     0x2E, 0x2C, 0x29, 0x2D,
        //     0x2E, 0x2E, 0x37, 0x3F,
        //     0x00, 0x00, 0x02, 0x10,
        // ])?;
        
        self.write_command(Instruction::NORON, &[])?;                   // Normal Display On
        delay.delay_ms(100);

        self.write_command(Instruction::DISPON, &[])?;                  // Display On
        delay.delay_ms(100);
        self.write_command(Instruction::RAMWR, &[])?;
        delay.delay_ms(200);
        Ok(())
    }

    pub fn hard_reset(&mut self, delay: &mut impl DelayMs<u8>) -> Result<(), ()> {
        self.rst.set_high().map_err(|_| ())?;
        delay.delay_ms(100);
        
        self.rst.set_low().map_err(|_| ())?;
        delay.delay_ms(100);

        self.rst.set_high().map_err(|_| ())?;
        delay.delay_ms(100);

        Ok(())
    }

    fn write_command(&mut self, cmd: Instruction, args: &[u8]) -> Result<(), ()> {
        let Some((spi, _)) = &mut self.tx else {
            return Err(());
        };
        self.dc.set_low().map_err(|_| ())?;
        spi.write(&[cmd as u8]).map_err(|_| ())?;

        if !args.is_empty() {
            self.dc.set_high().map_err(|_| ())?;
            spi.write(args).map_err(|_| ())?;
        }
        Ok(())
    }
}

impl<Spi, Dma, Dc, Rst> Screen for St7735<Spi, Dma, Dc, Rst>
where
    Spi: spi::Write<u8> + dma::WriteTarget<TransmittedWord = u8>,
    Dma: SingleChannel,
    Dc: OutputPin,
    Rst: OutputPin,
{
    fn write(&mut self, sbuf: &'static mut [Rgb565]) -> Result<(), ()> {
        // self.write_command(Instruction::MADCTL, &[0x20])?;              // Memory Access Control: Row/Col Addr, bottom-top refresh
        // self.write_command(Instruction::CASET, &[                       // Column Address Set
        //     0x0, 0x0,
        //     0x0, 160 - 1,
        // ])?;
        // self.write_command(Instruction::RASET, &[                       // Row Address Set
        //     0x0, 0x0,
        //     0x0, 128 - 1,
        // ])?;
        // self.write_command(Instruction::RAMWR, &[])?;
        // Take ownership of SPI, DMA so that no other instructions can occur while an
        // asynchronous transfer is in process.
        let Some((mut spi, dma)) = self.tx.take() else {
            return Err(());
        };
        
        let buf: &'static mut [u8] = unsafe {
            core::slice::from_raw_parts_mut(sbuf.as_mut_ptr() as _, sbuf.len() * 2)
        };
        // // Command: Memory Write
        // self.dc.set_low().map_err(|_| ())?;
        // spi.write(&[Instruction::CASET as u8]).map_err(|_| ())?;
        // self.dc.set_high().map_err(|_| ())?;
        // spi.write(&[0x0, 0x0, 0x0, 160 - 1]).map_err(|_| ())?;

        // self.dc.set_low().map_err(|_| ())?;
        // spi.write(&[Instruction::RASET as u8]).map_err(|_| ())?;
        // self.dc.set_high().map_err(|_| ())?;
        // spi.write(&[0x0, 0x0, 0x0, 128 - 1]).map_err(|_| ())?;

        // self.dc.set_low().map_err(|_| ())?;
        // spi.write(&[Instruction::RAMWR as u8]).map_err(|_| ())?;

        // Start Data
        // self.dc.set_low().map_err(|_| ())?;
        self.dc.set_high().map_err(|_| ())?;
        // spi.write(buf).map_err(|_| ())?;
        self.transfer = Some(Config::new(dma, buf, spi).start());

        Ok(())
    }

    fn is_done(&self) -> bool {
        match &self.transfer {
            Some(transfer) => transfer.is_done(),
            None => true,
        }
    }

    fn wait(&mut self) -> Result<&'static mut [Rgb565], ()> {
        let Some(transfer) = self.transfer.take() else {
            return Err(());
        };
        let (dma, buf, spi) = transfer.wait();

        self.tx = Some((spi, dma));

        Ok(unsafe {
            core::slice::from_raw_parts_mut(buf.as_mut_ptr() as _, buf.len() / 2)
        })
    }
}