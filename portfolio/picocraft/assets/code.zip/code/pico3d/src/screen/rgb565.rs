use crate::math::Fixed;

#[derive(Clone, Copy, PartialEq, Eq, Default)]
#[repr(transparent)]
pub struct Rgb565(pub u16);

#[allow(unused)]
impl Rgb565 {
    pub const BLACK: Self = Self::new(0, 0, 0);
    pub const WHITE: Self = Self::new(255, 255, 255);

    pub const fn new(r: u8, g: u8, b: u8) -> Self {
        let r = r as u16;
        let g = g as u16;
        let b = b as u16;

        Self(((r >> 3) << 11) | ((g >> 2) << 5) | (b >> 3))
    }

    pub const fn new_565(r: u8, g: u8, b: u8) -> Self {
        let r = r as u16;
        let g = g as u16;
        let b = b as u16;

        Self(r << 11 | g << 5 | b)
    }

    pub const fn flip(&self) -> Self {
        // Temporary hack: flip the bytes to fix endianess
        Self(self.0 << 8 | self.0 >> 8)
    }

    pub const fn r5(&self) -> u8 {
        (self.0 >> 11) as _
    }

    pub const fn g6(&self) -> u8 {
        (self.0 >> 5) as u8 & 0b111111
    }

    pub const fn b5(&self) -> u8 {
        (self.0 & 0b11111) as _
    }

    pub fn scale(&self, scalar: Fixed) -> Self {
        let d = (Fixed::from(1) / scalar).int().max(1) as u8;

        Self::new_565(self.r5() / d, self.g6() / d, self.b5() / d)
    }
}