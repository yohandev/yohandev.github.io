#![no_std]
#![no_main]

use embedded_hal::{spi, serial::Read};
use fugit::RateExtU32;
use rp_pico::{
    hal::{prelude::*, pll::common_configs::PLL_SYS_125MHZ},
    hal::dma::DMAExt,
    hal::{spi::Spi, clocks::ClockSource, multicore::{Stack, Multicore}, uart::{UartConfig, DataBits, StopBits}},
    hal::{pac, pll::common_configs::PLL_USB_48MHZ},
    hal,
    entry,
};

// use panic_halt as _;
use panic_probe as _;
use defmt_rtt as _;

use usb_device::{class_prelude::*, prelude::*};
use usb_device::class_prelude::UsbBusAllocator;
use usbd_serial::SerialPort;

mod game;
mod screen;
mod voxel;
mod graphics;
mod math;

static mut CORE1_STACK: Stack<2048> = Stack::new();

#[entry]
fn main() -> ! {
    let mut pac = pac::Peripherals::take().unwrap();
    let mut watchdog = hal::Watchdog::new(pac.WATCHDOG);
    
    let core = pac::CorePeripherals::take().unwrap();
    // let mut clocks = hal::clocks::init_clocks_and_plls(
    //     rp_pico::XOSC_CRYSTAL_FREQ,
    //     pac.XOSC,
    //     pac.CLOCKS,
    //     pac.PLL_SYS,
    //     pac.PLL_USB,
    //     &mut pac.RESETS,
    //     &mut watchdog,
    // ).ok().unwrap();
    
    // defmt::info!("Running at {}", clocks.system_clock.freq().to_Hz());
    
    // let xosc = hal::xosc::setup_xosc_blocking(pac.XOSC, rp_pico::XOSC_CRYSTAL_FREQ.Hz()).unwrap();
    // let pll_sys = hal::pll::setup_pll_blocking(pac.PLL_SYS, xosc.operating_frequency().into(), PLL_SYS_125MHZ, &mut clocks, &mut pac.RESETS).unwrap();
    // clocks.system_clock.configure_clock(&pll_sys, 270u32.MHz());
    
    // Clocks setup code adapted from:
    // https://docs.rs/rp2040-hal/latest/rp2040_hal/clocks/index.html
    let clocks = {
        let xosc = hal::xosc::setup_xosc_blocking(pac.XOSC, rp_pico::XOSC_CRYSTAL_FREQ.Hz()).unwrap();

        watchdog.enable_tick_generation((rp_pico::XOSC_CRYSTAL_FREQ / 1_000_000) as u8);

        let mut clocks = hal::clocks::ClocksManager::new(pac.CLOCKS);

        // Configure PLLs
        //                   REF     FBDIV VCO            POSTDIV
        // PLL SYS: 12 / 1 = 12MHz * 125 = 1500MHZ / 6 / 2 = 125MHz
        // PLL USB: 12 / 1 = 12MHz * 40  = 480 MHz / 5 / 2 =  48MHz
        let mut pll_sys = PLL_SYS_125MHZ;
        // (ADAPTED) Configure PLLs
        //                   REF     FBDIV VCO            POSTDIV
        // PLL SYS: 12 / 1 = 12MHz * 125 = 1500MHZ / 6 / 1 = 250MHz
        // PLL USB: 12 / 1 = 12MHz * 40  = 480 MHz / 5 / 2 =  48MHz
        pll_sys.post_div2 = 1;
        let pll_sys = hal::pll::setup_pll_blocking(pac.PLL_SYS, xosc.operating_frequency().into(), pll_sys, &mut clocks, &mut pac.RESETS).unwrap();
        let pll_usb = hal::pll::setup_pll_blocking(pac.PLL_USB, xosc.operating_frequency().into(), PLL_USB_48MHZ, &mut clocks, &mut pac.RESETS).unwrap();

        // Configure clocks
        // CLK_REF = XOSC (12MHz) / 1 = 12MHz
        clocks.reference_clock.configure_clock(&xosc, xosc.get_freq()).unwrap();

        // CLK SYS = PLL SYS (125MHz) / 1 * 2 = 250MHz
        clocks.system_clock.configure_clock(&pll_sys, pll_sys.get_freq()).unwrap();

        // CLK USB = PLL USB (48MHz) / 1 = 48MHz
        clocks.usb_clock.configure_clock(&pll_usb, pll_usb.get_freq()).unwrap();

        // CLK ADC = PLL USB (48MHZ) / 1 = 48MHz
        clocks.adc_clock.configure_clock(&pll_usb, pll_usb.get_freq()).unwrap();

        // CLK RTC = PLL USB (48MHz) / 1024 = 46875Hz
        clocks.rtc_clock.configure_clock(&pll_usb, 46875u32.Hz()).unwrap();

        // CLK PERI = clk_sys. Used as reference clock for Peripherals. No dividers so just select and enable
        // Normally choose clk_sys or clk_usb
        clocks.peripheral_clock.configure_clock(&clocks.system_clock, clocks.system_clock.freq()).unwrap();

        clocks
    };

    defmt::info!("Overclocking at {}", clocks.system_clock.freq().to_Hz());

    let mut sio = hal::Sio::new(pac.SIO);
    let pins = rp_pico::Pins::new(
        pac.IO_BANK0,
        pac.PADS_BANK0,
        sio.gpio_bank0,
        &mut pac.RESETS,
    );

    let mut delay = cortex_m::delay::Delay::new(core.SYST, clocks.system_clock.freq().to_Hz());

    let mut screen = {
        let spi = Spi::<_, _, _, 8>::new(pac.SPI0, (
            pins.gpio19.into_function(),
            pins.gpio18.into_function(),
            // pins.gpio6.into_function(),
        ));
        let spi = spi.init(
            &mut pac.RESETS,
            clocks.peripheral_clock.freq(),
            31_250_000u32.Hz(),
            spi::MODE_0,
        );
        let dma = pac.DMA.split(&mut pac.RESETS);
        
        let mut screen = screen::St7735::new(
            spi,
            dma.ch0,
            pins.gpio15.into_push_pull_output(),
            pins.gpio14.into_push_pull_output(),
        );
        screen.init(160, 128, &mut delay).unwrap();
        screen
    };

    let mut led = pins.led.into_push_pull_output();

    let mut mc = Multicore::new(&mut pac.PSM, &mut pac.PPB, &mut sio.fifo);
    let cores = mc.cores();
    let core1 = &mut cores[1];
    core1.spawn(unsafe { &mut CORE1_STACK.mem }, move || {
        game::core1();
    })
    .unwrap();

    // let uart_pins = (
    //     // UART TX (characters sent from RP2040) on pin 1 (GPIO0)
    //     pins.gpio0.into_function(),
    //     // UART RX (characters received by RP2040) on pin 2 (GPIO1)
    //     pins.gpio1.into_function(),
    // );
    // let mut uart = hal::uart::UartPeripheral::new(pac.UART0, uart_pins, &mut pac.RESETS)
    //     .enable(
    //         UartConfig::new(9600.Hz(), DataBits::Eight, None, StopBits::One),
    //         clocks.peripheral_clock.freq(),
    //     )
    //     .unwrap();
    let usb_bus = UsbBusAllocator::new(hal::usb::UsbBus::new(
        pac.USBCTRL_REGS,
        pac.USBCTRL_DPRAM,
        clocks.usb_clock,
        true,
        &mut pac.RESETS,
    ));

    // Set up the USB Communications Class Device driver
    let mut serial = SerialPort::new(&usb_bus);

    // Create a USB device with a fake VID and PID
    let mut usb_dev = UsbDeviceBuilder::new(&usb_bus, UsbVidPid(0x16c0, 0x27dd))
        .manufacturer("Fake company")
        .product("Serial port")
        .serial_number("TEST")
        .device_class(2) // from: https://www.usb.org/defined-class-codes
        .build();

    // let serial_available = || uart.uart_is_readable();
    // let serial_read = |buf| uart.read_full_blocking(buf).unwrap();
    let serial_available = || true;
    let serial_read = |buf: &mut [u8]| ();

    let poll = |buf| {
        if usb_dev.poll(&mut [&mut serial]) {
            serial.read(buf).unwrap();

            true
        } else {
            false
        }
    };
    // uart.read_full_blocking(buffer)

    game::core0(&mut screen, &mut led, serial_available, poll);
}