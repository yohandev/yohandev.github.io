use core::ops::{
    Add, Sub, Mul, Div,
    Shr, Shl,
    AddAssign, SubAssign, MulAssign, DivAssign,
    Neg,
};
use vek::num_traits::Float;

/// Fixed-point decimal with `D` fractional bits
#[derive(Debug, Default, Clone, Copy, PartialEq, Eq, PartialOrd, Ord)]
pub struct Fixed<const D: usize = 15, T = i32>(T) where T: FixedInner;

pub trait FixedInner: Sized
    + Copy
    + Add<Output=Self>
    + Sub<Output=Self>
    + Mul<Output=Self>
    + Div<Output=Self>
    + Shr<usize, Output = Self>
    + Shl<usize, Output = Self>
    + Neg<Output = Self>
{
    type Bigger: From<Self>
        + Add<Output=Self::Bigger>
        + Sub<Output=Self::Bigger>
        + Mul<Output=Self::Bigger>
        + Div<Output=Self::Bigger>
        + Shr<usize, Output = Self::Bigger>
        + Shl<usize, Output = Self::Bigger>;
    
    const ZERO: Self;
    const ONE: Self;

    const MAX: Self;
    const MIN: Self;
    
    fn truncate(x: Self::Bigger) -> Self;
}

impl FixedInner for i16 {
    type Bigger = i32;

    const ZERO: Self = 0;
    const ONE: Self = 1;

    const MAX: Self = Self::MAX;
    const MIN: Self = Self::MIN;

    fn truncate(x: Self::Bigger) -> Self {
        x as Self
    }
}

impl FixedInner for i32 {
    type Bigger = i64;

    const ZERO: Self = 0;
    const ONE: Self = 1;

    const MAX: Self = Self::MAX;
    const MIN: Self = Self::MIN;

    fn truncate(x: Self::Bigger) -> Self {
        x as Self
    }
}

impl<const D: usize, T: FixedInner> Fixed<D, T> {
    pub const fn zero() -> Self {
        Self(T::ZERO)
    }

    pub fn one() -> Self {
        Self(T::ONE << D)
    }

    pub const fn max() -> Self {
        Self(T::MAX)
    }

    pub const fn min() -> Self {
        Self(T::MIN)
    }

    pub fn int(&self) -> T {
        self.0 >> D
    }
}

impl<const D: usize> Fixed<D, i16> {
    fn new(x: f32) -> Self {
        Self((x * 2.0f32.powi(D as i32)) as _)
    }

    pub fn f32(&self) -> f32 {
        self.0 as f32 / 2.0f32.powi(D as i32)
    }

    pub fn sqrt(&self) -> Self {
        Self::new(self.f32().sqrt())
    }

    pub fn abs(&self) -> Self {
        Self(self.0.abs())
    }

    // pub fn try_div(&self, rhs: Self) -> Option<Self> {
    //     match rhs {
    //         Self(0) => None,
    //         _ => Some(*self / rhs)
    //     }
    // }
}

impl<const D: usize> Fixed<D, i32> {
    pub fn new(x: f32) -> Self {
        Self((x * 2.0f32.powi(D as i32)) as _)
    }

    pub fn f32(&self) -> f32 {
        self.0 as f32 / 2.0f32.powi(D as i32)
    }

    pub fn sqrt(&self) -> Self {
        Self::new(self.f32().sqrt())
    }

    pub fn abs(&self) -> Self {
        Self(self.0.abs())
    }

    pub fn try_div(&self, rhs: Self) -> Option<Self> {
        match rhs {
            Self(0) => None,
            _ => Some(*self / rhs)
        }
    }
}

impl<const D: usize, T: FixedInner> Add for Fixed<D, T> {
    type Output = Self;

    fn add(self, rhs: Self) -> Self::Output {
        Self(self.0 + rhs.0)
    }
}

impl<const D: usize, T: FixedInner> Sub for Fixed<D, T> {
    type Output = Self;

    fn sub(self, rhs: Self) -> Self::Output {
        Self(self.0 - rhs.0)
    }
}

impl<const D: usize, T: FixedInner> Mul for Fixed<D, T> {
    type Output = Self;

    fn mul(self, rhs: Self) -> Self::Output {
        let a: T::Bigger = self.0.into();
        let b: T::Bigger = rhs.0.into();

        Self(T::truncate((a * b) >> D))
    }
}

impl<const D: usize, T: FixedInner> Div for Fixed<D, T> {
    type Output = Self;

    fn div(self, rhs: Self) -> Self::Output {
        let a: T::Bigger = self.0.into();
        let b: T::Bigger = rhs.0.into();

        Self(T::truncate((a << D) / b))
    }
}

impl<const D: usize, T: FixedInner> AddAssign for Fixed<D, T> {
    fn add_assign(&mut self, rhs: Self) {
        *self = *self + rhs;
    }
}

impl<const D: usize, T: FixedInner> SubAssign for Fixed<D, T> {
    fn sub_assign(&mut self, rhs: Self) {
        *self = *self - rhs;
    }
}

impl<const D: usize, T: FixedInner> MulAssign for Fixed<D, T> {
    fn mul_assign(&mut self, rhs: Self) {
        *self = *self * rhs;
    }
}

impl<const D: usize, T: FixedInner> DivAssign for Fixed<D, T> {
    fn div_assign(&mut self, rhs: Self) {
        *self = *self / rhs;
    }
}

impl<const D: usize, T: FixedInner> Neg for Fixed<D, T> {
    type Output = Self;

    fn neg(self) -> Self::Output {
        Self(-self.0)
    }
}

impl<const D: usize, T: FixedInner> From<T> for Fixed<D, T> {
    fn from(value: T) -> Self {
        Self(value << D)
    }
}