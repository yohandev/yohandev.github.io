pub use vek::{Vec2, Vec3};
pub use fixed::Fixed;

mod fixed;